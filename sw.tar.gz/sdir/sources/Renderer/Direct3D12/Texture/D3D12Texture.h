/*
 * D3D12Texture.h
 * 
 * This file is part of the "LLGL" project (Copyright (c) 2015-2018 by Lukas Hermanns)
 * See "LICENSE.txt" for license information.
 */

#ifndef LLGL_D3D12_TEXTURE_H
#define LLGL_D3D12_TEXTURE_H


#include <LLGL/Texture.h>
#include "../D3D12Resource.h"


namespace LLGL
{


class D3D12Texture final : public Texture
{

    public:

        D3D12Texture(ID3D12Device* device, const TextureDescriptor& desc);

        Extent3D QueryMipExtent(std::uint32_t mipLevel) const override;

        TextureDescriptor QueryDesc() const override;

    public:

        void UpdateSubresource(
            ID3D12Device*               device,
            ID3D12GraphicsCommandList*  commandList,
            ComPtr<ID3D12Resource>&     uploadBuffer,
            D3D12_SUBRESOURCE_DATA&     subresourceData,
            UINT                        firstArrayLayer = 0,
            UINT                        numArrayLayers  = ~0
        );

        void CreateResourceView(ID3D12Device* device, D3D12_CPU_DESCRIPTOR_HANDLE cpuDescriptorHandle);

        // Returns the resource wrapper.
        inline D3D12Resource& GetResource()
        {
            return resource_;
        }

        // Returns the constant resource wrapper.
        inline const D3D12Resource& GetResource() const
        {
            return resource_;
        }

        // Returns the native ID3D12Resource object.
        inline ID3D12Resource* GetNative() const
        {
            return resource_.native.Get();
        }

        // Returns the hardware resource format.
        inline DXGI_FORMAT GetFormat() const
        {
            return format_;
        }

        // Returns the number of MIP-map levels specified at creation time.
        inline UINT GetNumMipLevels() const
        {
            return numMipLevels_;
        }

        // Returns the number of array layers of the hardware resource (for cube textures, this is a multiple of 6)
        inline UINT GetNumArrayLayers() const
        {
            return numArrayLayers_;
        }

    private:

        void CreateNativeTexture(ID3D12Device* device, const TextureDescriptor& desc);

    private:

        D3D12Resource   resource_;

        DXGI_FORMAT     format_         = DXGI_FORMAT_UNKNOWN;
        UINT            numMipLevels_   = 0;
        UINT            numArrayLayers_ = 0;

};


} // /namespace LLGL


#endif



// ================================================================================
